---
title: 'Tutorials | Blog Posts'
---

This site lists blog entries that write about the project. If you blogged about DMS let us know so we can add it here!

- [Installing docker-mailserver](https://lowtek.ca/roo/2021/installing-docker-mailserver/) by [@andrewlow](https://github.com/andrewlow)
- [Self hosted mail-server](https://www.ifthenel.se/self-hosted-mail-server/) by [@matrixes](https://github.com/matrixes)
- [Docker-mailserver on kubernetes](https://brakkee.org/site/index.php/mailserver-on-kubernetes/) by [@ErikEngerd](https://github.com/ErikEngerd)
